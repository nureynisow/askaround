/*
 * list.c
 *
 *  Created on: 7 avr. 2014
 *      Author: ptoure
 *

#include<list.h>
struct list {
	cell head;
	int size;
};

struct cell {
	void* data;
	cell next;
	cell previous;
};
list* list_init(void* data) {

    list* list = malloc(sizeof(*list));
    cell* cell=malloc(sizeof(*cell));

    assert(list);
    assert(cell);

    cell->data=data;
    cell->next = NULL;
    cell->previous = NULL;

    list->head = cell;

    return list;
}

list* list_add(list* list, void* data){
	assert(list);

	cell* cell=malloc(sizeof(*cell));
	assert(cell);

	cell->data=data;
    cell->next=list->head;
    cell->previous=NULL;
    list->head->previous=cell;
    list->head=cell;
    list->size +=1;

    return list;
  }


cell* list_get_head(list* list) {
		assert(list);

		return list->head;
}

void* list_cell_get_data(cell* cell) {
	assert(cell);

	return cell->data;
}

cell* list_get_next_cell(t_cell cell) {
	assert(cell);

	return cell->next;
}


cell* list_get_previous_cell(cell* cell) {
	assert(cell);

	return cell->previous;
}

 list* list_delete(list* list, void* data) {

	assert(list);

	t_cell key=list->head;
	int found=0;

	while (key->data != NULL && !found) {
		if(key->data==data) {

			if(key->previous==NULL && key->next !=NULL) {
				list->head=list_get_next_cell(key);
				list->head->previous=NULL;
			}

			else if(key->next==NULL && key->previous != NULL) {
				key->previous->next=NULL;
			}

			else if(key->previous==NULL && key->next==NULL){
				list=NULL;
			}
			else {
				key->previous->next=key->next;
				key->next->previous=key->previous;
			}
			free(key);
			found=1;
			}
		else key=list_get_next_cell(key);
	}
	return list;
}

 list* list_cell_replace(list* list, void* data, int num){
	 assert(list);

	 t_cell key=list_get_head(list);

	 t_cell cell=malloc(sizeof(*cell));
		 	assert(cell);

		 	cell->data=data;

	if(num){
	 while(num){
		 key=list_get_next_cell(key);
		 num -=1;
	 }

	 	 if(key->next){  //milieu de liste
		 t_cell key_p=list_get_previous_cell(key);
		 t_cell key_n=list_get_next_cell(key);

		 cell->next=key->next;
		 cell->previous=key->previous;
		 key_p->next=cell;
		 key_n->previous=cell;
	 }

	 else {
		 t_cell key_p=list_get_previous_cell(key);

		 cell->previous=key->previous;
		 key_p->next=cell;
	 }
	}
	else {
			t_cell key_n=list_get_next_cell(key);

			 list->head=cell;
			 cell->next=key_n;
			 key_n->previous=cell;
		 }
     free(key);
	 return list;
 }


 //struct list * list () {

*/
#include <SDL/SDL_image.h>
#include <assert.h>
#include <bomb.h>
#include <sprite.h>
#include <window.h>
#include <misc.h>
#include <constant.h>
#include <game.h>
#include <player.h>
#include <map.h>
#include <list.h>


struct list {
	struct cell* head;
	int size;
};

struct cell {
	void* data;
	struct cell* next;
	struct cell* previous;
};
struct list* list_init(void* data) {

    struct list* list = malloc(sizeof(*list));
    struct cell* cell=malloc(sizeof(*cell));

    assert(list);
    assert(cell);

    cell->data=data;
    cell->next = NULL;
    cell->previous = NULL;

    list->head = cell;

    return list;
}

struct list* list_add(struct list* list, void* data){
	assert(list);

	struct cell* cell=malloc(sizeof(*cell));
	assert(cell);

	cell->data=data;
    cell->next=list->head;
    cell->previous=NULL;
    list->head->previous=cell;
    list->head=cell;
    list->size +=1;

    return list;
  }


struct cell* list_get_head(struct list* list) {
		assert(list);

		return list->head;
}

void* list_cell_get_data(struct cell* cell) {
	assert(cell);

	return cell->data;
}

struct cell* list_get_next_cell(struct cell* cell) {
	assert(cell);

	return cell->next;
}


struct cell* list_get_previous_cell(struct cell* cell) {
	assert(cell);

	return cell->previous;
}

 struct list* list_delete(struct list* list, void* data) {

	assert(list);

	struct cell* key=list->head;
	int found=0;

	while (key->data != NULL && !found) {
		if(key->data==data) {

			if(key->previous==NULL && key->next !=NULL) {
				list->head=list_get_next_cell(key);
				list->head->previous=NULL;
			}

			else if(key->next==NULL && key->previous != NULL) {
				key->previous->next=NULL;
			}

			else if(key->previous==NULL && key->next==NULL){
				list=NULL;
			}
			else {
				key->previous->next=key->next;
				key->next->previous=key->previous;
			}
			free(key);
			found=1;
			}
		else key=list_get_next_cell(key);
	}
	return list;
}

 struct list* list_cell_replace(struct list* list, void* data, int num){
	 assert(list);

	 struct cell* key=list_get_head(list);

	 struct cell* cell=malloc(sizeof(*cell));
		 	assert(cell);

		 	cell->data=data;

	if(num){
	 while(num){
		 key=list_get_next_cell(key);
		 num -=1;
	 }

	 	 if(key->next){  //milieu de liste
		 struct cell* key_p=list_get_previous_cell(key);
		 struct cell* key_n=list_get_next_cell(key);

		 cell->next=key->next;
		 cell->previous=key->previous;
		 key_p->next=cell;
		 key_n->previous=cell;
	 }

	 else {
		 struct cell* key_p=list_get_previous_cell(key);

		 cell->previous=key->previous;
		 key_p->next=cell;
	 }
	}
	else {
			struct cell* key_n=list_get_next_cell(key);

			 list->head=cell;
			 cell->next=key_n;
			 key_n->previous=cell;
		 }
     free(key);
	 return list;
 }

