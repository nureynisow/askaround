#include <SDL/SDL_image.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>

#include <monster.h>
#include <game.h>
#include <sprite.h>
#include <window.h>
#include <misc.h>
#include <constant.h>
#include <time.h>
#include <map.h>
#include <player.h>


struct monster {
	int x, y;
	//int last_move;
	enum way current_way;

	struct monster *nxt;
	int last_move;
};

struct monster* monster_init() {
	struct monster* monster = malloc(sizeof(*monster));
	if (!monster)
		error("Memory error");
	monster->nxt = NULL;

	return monster;
}

void monster_from_map(struct monster* monster, struct map* map) {
	assert(monster);
	assert(map);

	for (int i = 0; i < map_get_width(map); i++) {
		for (int j = 0; j < map_get_height(map); j++) {
			if (map_get_cell_type(map, i, j) == CELL_MONSTER) {
				add_monster(monster, i, j);
			}
		}
	}

}

void monster_free(struct monster* monster) {
	assert(monster);
	struct monster* tmp;
	do {
		tmp = monster->nxt;
		free(monster);
		monster = tmp;
	} while (monster->nxt != NULL);
}

void add_monster(struct monster* monster, int x, int y) {
	assert(monster);
	struct monster* newmonster = malloc(sizeof(*monster));

	monster = get_last_monster(monster);
	newmonster->nxt = NULL;

	monster->nxt = newmonster;
	monster->x = x;
	monster->y = y;
	monster->current_way = SOUTH;
	monster->last_move = 0;
}

/*void delete_monster(struct map* map, int x, int y) {
	assert(map);
	struct monster* monster = map_get_monster(map);
	struct monster* tmp = monster;

	if (monster->x == x && monster->y == y && monster->nxt == NULL) {
		free(monster);
		struct monster* newmonster = malloc(sizeof(*monster));
		monster->nxt = NULL;
		map_set_monster(map, newmonster);
		return;
	} else if (monster->x == x && monster->y == y) {
		tmp = tmp->nxt;
		map_set_monster(map, tmp);
		free(monster);
		return;
	} else {
		tmp = tmp->nxt;

		do {
			if (tmp->x == x && tmp->y == y) {
				if (tmp->nxt != NULL) {
					monster->nxt = tmp->nxt;
				} else {
					monster->nxt = NULL;
				}
				free(tmp);
				return;
			}

			tmp = tmp->nxt;
			monster = monster->nxt;
		} while (tmp->nxt != NULL);
	}
}*/

struct monster* get_last_monster(struct monster* monster) {
	assert(monster != NULL);
	while (monster->nxt != NULL)
		monster = monster->nxt;

	return monster;
}

int monster_get_x(struct monster* monster) {
	assert(monster != NULL);
	return monster->x;
}

int monster_get_y(struct monster* monster) {
	assert(monster != NULL);
	return monster->y;
}

void monster_set_current_way(struct monster* monster, enum way way) {
	assert(monster);
	monster->current_way = way;
}

static int monster_move_aux(struct monster* monster, struct map* map, struct player* player, int x, int y) {

	if (!map_is_inside(map, x, y))
		return 0;

	switch (map_get_cell_type(map, x, y)) {
	case CELL_SCENERY:
		return 0;
		break;

	case CELL_CASE:
		return 0;
		break;

	case CELL_BONUS:
		return 0;
		break;
	case CELL_GOAL:
		break;

	case CELL_MONSTER:
		return 0;
		break;

	case CELL_PLAYER:
		player_dec_life(player);
		return 1;
		break;

	default:
		break;
	}

	// Monster has moved
	return 1;
	}

int monster_move(struct monster* monster, struct map* map,struct player* player) {

	int x = monster->x;
	int y = monster->y;
	int move = 0;

		switch (monster->current_way) {
		case NORTH:
		if (monster_move_aux(monster, map, player, x, y - 1)) {

		monster->y--;
		move = 1;

		}

		break;

	case SOUTH:
		if (monster_move_aux(monster, map, player, x, y + 1)) {
			monster->y++;
			move = 1;
		}
		break;

	case WEST:
		if (monster_move_aux(monster, map, player,  x - 1, y)) {
			monster->x--;
			move = 1;
 		}
		break;

	case EAST:
		if (monster_move_aux(monster, map, player, x + 1, y)) {
			monster->x++;
			move = 1;
		}
		break;
	}

	if (move) {
		map_set_cell_type(map, x, y, CELL_EMPTY);
		map_set_cell_type(map, monster->x, monster->y, CELL_MONSTER);
	}
	return move;
}

void monster_display(struct monster* monster) {
	assert(monster);
	switch(monster->current_way){
	case WEST :
	window_display_image(sprite_get_monster_west(),(monster->x)*SIZE_BLOC,(monster->y)*SIZE_BLOC);
    break;
	case EAST :
		window_display_image(sprite_get_monster_east(),(monster->x)*SIZE_BLOC,(monster->y)*SIZE_BLOC);
	    break;
	case NORTH :
		window_display_image(sprite_get_monster_north(),(monster->x)*SIZE_BLOC,(monster->y)*SIZE_BLOC);
	    break;
	case SOUTH :
		window_display_image(sprite_get_monster_south(),(monster->x)*SIZE_BLOC,(monster->y)*SIZE_BLOC);
	    break;
	default :
		break;
	}
	}


