#include <SDL/SDL_image.h>
#include <assert.h>
#include <bomb.h>
#include <sprite.h>
#include <window.h>
#include <misc.h>
#include <constant.h>
#include <game.h>
#include <player.h>
//#include <map.h>
//int i;

struct bomb {
	int x, y;
	enum state current_state;
	int timer;
	int had_explode;
};


struct bomb* bomb_init(int x, int y) {
	struct bomb* bomb = malloc(sizeof(*bomb));
	bomb->current_state=TTL1;
	bomb->x = x;
	bomb->y = y;
	bomb->timer=SDL_GetTicks();
	bomb->had_explode = 0 ;
	return bomb;

}
void bomb_update(struct bomb* bomb, struct map* map,struct player* player) {
	bomb->current_state = (SDL_GetTicks()- bomb->timer)/1000;


}
int bomb_get_state(struct bomb* bomb){
	assert(bomb);
	return bomb->current_state ;
}
void display_explosion(struct map* map, struct bomb* bomb , struct player* player) {
	assert(bomb);

	int a=bomb->x;
	int b=bomb->y;
	int i;

	for(i=0; i<2+player_get_nb_range(player); i++) {
		if(map_is_inside(map_get_default(), a+i, b)==1){
			if(map_get_cell_type(map_get_default(), a+i, b)!=CELL_SCENERY){
				 window_display_image(sprite_get_bomb_explode(),(a+i)*SIZE_BLOC,(b)*SIZE_BLOC);
				 display_explosion_aux(map, a+i, b,player);

				 }
			}
			else break;
		//}
	}
	for(i=0; i<2+player_get_nb_range(player); i++) {
			if(map_is_inside(map_get_default(), a-i, b)==1){
				if(map_get_cell_type(map_get_default(), a-i, b)!=CELL_SCENERY){
					window_display_image(sprite_get_bomb_explode(),(a-i)*SIZE_BLOC,(b)*SIZE_BLOC);
					display_explosion_aux(map, a-i, b,player);
				}
				else break;
			}
		}
	for(i=0; i<2+player_get_nb_range(player); i++) {
			if(map_is_inside(map_get_default(), a, b+i)==1){
				if(map_get_cell_type(map_get_default(), a, b+i)!=CELL_SCENERY){
					 window_display_image(sprite_get_bomb_explode(),(a)*SIZE_BLOC,(b+i)*SIZE_BLOC);
					 display_explosion_aux(map, a, b+i,player);

				}
				else break;
			}
		}
	for(i=0; i<2+player_get_nb_range(player); i++) {
			if(map_is_inside(map_get_default(), a, b-i)==1){
				if(map_get_cell_type(map_get_default(), a, b-i)!=CELL_SCENERY){
					window_display_image(sprite_get_bomb_explode(),(a)*SIZE_BLOC,(b-i)*SIZE_BLOC);
					display_explosion_aux(map, a, b-i,player);

				}
				else break;
			}
		}
}

void bomb_display(struct map* map, struct bomb* bomb , struct player* player) {
	//int i;

	assert(bomb);
		//printf("bomb->state = %d\n");
	switch (bomb->current_state) {
		case TTL1:
	         window_display_image(sprite_get_bomb4(),(bomb->x)*SIZE_BLOC,(bomb->y)*SIZE_BLOC);
	         break;
	    case TTL2:
	         window_display_image(sprite_get_bomb3(),(bomb->x)*SIZE_BLOC,(bomb->y)*SIZE_BLOC);
	         break;
	    case TTL3:
	         window_display_image(sprite_get_bomb2(),(bomb->x)*SIZE_BLOC,(bomb->y)*SIZE_BLOC);
	         break;
	    case TTL4:
	         window_display_image(sprite_get_bomb1(),(bomb->x)*SIZE_BLOC,(bomb->y)*SIZE_BLOC);
	         break;
	    case TTL5:
	    	 display_explosion(map, bomb , player);
	    	 break;
	    default:
	    	break;
	    		//printf("bomb->had_explode = %d\n");
	}
	//bomb->current_state = TTL1;
	//printf("bomb->current_state = %d\n");
}

void bomb_free(struct bomb* bomb) {
	assert(bomb);
	free(bomb);
}

int bomb_get_x(struct bomb* bomb) {
	assert(bomb);
	return bomb->x;
}

int bomb_get_y(struct bomb* bomb) {
	assert(bomb);
	return bomb->y;
}

int bomb_get_timer(struct bomb* bomb) {
	assert(bomb);
	return bomb->timer;
}



static int display_explosion_aux(struct map* map, int x, int y, struct player* player) {


if (!map_is_inside(map, x, y))

return 1;

switch (map_get_cell_type(map, x, y)) {

	case CELL_SCENERY:

	return 0;

	break;

	case CELL_MONSTER:

	//monster_erase(map, x, y);

	map_set_cell_type(map,x,y,CELL_EMPTY);

	return 1;

	break;

	case CELL_PLAYER:

	player_dec_life(player);

	return 0;

	break;

	case CELL_BONUS:

	//map_set_cell_type(map,x,y,CELL_EMPTY);

	break;

	case CELL_CASE:


		map_display_random(map,x,y);
		return 1;
		break;

	default:

	window_display_image( sprite_get_bomb_explode(), x * SIZE_BLOC, y * SIZE_BLOC);

	break;
}
switch (map_get_compose_type(map, x, y)){
	case CELL_CASE_BOMBINC:
		map_set_cell_type(map,x,y,CELL_BONUS_BOMB_NB_INC);
		return 1;
		break;
	case CELL_CASE_BOMBDEC:
		map_set_cell_type(map,x,y,CELL_BONUS_BOMB_NB_DEC);
		return 1;
	break;
	case CELL_CASE_RANGEINC:
		map_set_cell_type(map,x,y,CELL_BONUS_BOMB_RANGE_INC);
		return 1;
		break;
	case CELL_CASE_RANGEDEC:
		map_set_cell_type(map,x,y,CELL_BONUS_BOMB_RANGE_DEC);
		return 1;
		break;
	case CELL_CASE_LIFE:
		map_set_cell_type(map,x,y,CELL_BONUS_LIFE);
		return 1;
		break;
	case CELL_CASE_MONSTER:
		map_set_cell_type(map,x,y,CELL_MONSTER);
		return 1;
		break;


	default:

	window_display_image( sprite_get_bomb_explode(), x * SIZE_BLOC, y * SIZE_BLOC);

	break;

	}

	return 0;

	}
