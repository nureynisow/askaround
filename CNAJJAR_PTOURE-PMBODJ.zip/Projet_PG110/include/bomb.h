
#ifndef BOMB_H_
#define BOMB_H_

#include <player.h>
#include <map.h>
#include <constant.h>


struct bomb;
struct player* player_init(int bomb_number );
struct bomb* bomb_init(int x, int y);
//void bomb_display(struct bomb* bomb);
void bomb_free(struct bomb* bomb);
int bomb_get_x(struct bomb* bomb);
int bomb_get_y(struct bomb* bomb);
int bomb_get_timer(struct bomb* bomb);
void bomb_update(struct bomb* bomb,struct map* map,struct player* player);
//void bomb_display(struct bomb* bomb);
int bomb_get_state(struct bomb* bomb);
//void bomb_display(struct bomb* bomb , struct player* playe);
void bomb_TTL5(struct bomb* bomb , struct player* player);
void bomb_explode(struct bomb* bomb , struct player* player, struct map* map);
void display_explosion(struct map* map,struct bomb*bomb, struct player* player);
static int display_explosion_aux(struct map* map, int x, int y, struct player* player);
//static int display_explosion_aux(struct map* map,int x, int y, struct player* player);
void bomb_display(struct map* map, struct bomb* bomb , struct player* player);
#endif /* BOMB_H_ */
