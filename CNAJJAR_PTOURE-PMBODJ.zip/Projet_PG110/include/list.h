/*
 * list.h
 *
 *  Created on: 7 avr. 2014
 *      Author: ptoure
 */


#ifndef LIST_H_
#define LIST_H_

typedef struct list*  list;
typedef struct cell* cell;

struct list* list_init(void* data);
struct list* list_add(struct list* list, void* data);
struct cell* list_get_head(struct list* list);
int list_get_size(list* list);
struct cell* list_get_previous_cell(struct cell* cell);
struct cell* list_get_next_cell(cell cell);
struct list* list_delete(struct list* list, void* data);
struct list* list_cell_replace(struct list* list, void* data, int num);

#endif /* LIST_H_ */

