#ifndef SPRITE_H_
#define SPRITE_H_

#include <SDL/SDL.h>
#include <map.h>
#include <constant.h>

// load game's sprites
void sprite_load();
void bomb_load();
void monster_load();
void monster_unload();
SDL_Surface* sprite_get_player(way_t direction);
SDL_Surface* sprite_get_bonus(bonus_type_t bonus_type);
SDL_Surface* sprite_get_tree();
SDL_Surface* sprite_get_box();
SDL_Surface* sprite_get_key();
SDL_Surface* sprite_get_stone();
SDL_Surface* sprite_get_door();
SDL_Surface* sprite_get_closed_door();
//SDL_Surface* sprite_get_bomb(state_t num);
SDL_Surface* sprite_get_number(short number);
SDL_Surface* sprite_get_banner_life();
SDL_Surface* sprite_get_banner_bomb();
SDL_Surface* sprite_get_banner_line();
SDL_Surface* sprite_get_banner_range();
SDL_Surface* sprite_get_bomb1();
SDL_Surface* sprite_get_bomb2();
SDL_Surface* sprite_get_bomb3();
SDL_Surface* sprite_get_bomb4();
SDL_Surface* sprite_get_bomb_explode();
SDL_Surface* sprite_get_monster_west();
SDL_Surface* sprite_get_monster_east();
SDL_Surface* sprite_get_monster_north();
SDL_Surface* sprite_get_monster_south();



//SDL_Surface* sprite_get_monster(enum way direction);
#endif /* SPRITE_H_ */
