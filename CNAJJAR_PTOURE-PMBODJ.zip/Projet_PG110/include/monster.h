#ifndef MONSTER_H_
#define MONSTER_H_



struct monster;
struct monster* monster_init();
//void monster_from_map(struct monster* monster, struct map* map);
void monster_free(struct monster* monster);
void add_monster(struct monster* monster, int x, int y);
//void delete_monster(struct map* map, int x, int y);
struct monster* get_last_monster(struct monster* monster);
int monster_get_x(struct monster* monster);
int monster_get_y(struct monster* monster);
//void monster_set_current_way(struct monster* monster, enum way way);
//static int monster_move_aux(struct monster* monster, struct map* map, struct player* player, int x, int y);
//int monster_move(struct monster* monster, struct map* map,struct player* player);
//void monster_update(struct game* game);
void monster_display(struct monster* monster);

#endif /* MONSTER_H_ */
